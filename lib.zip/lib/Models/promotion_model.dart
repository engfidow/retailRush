// models/promotion.dart
class Promotion {
  final String? id;
  final String name;
  final String description;
  final bool isTrending;
  final String image;

  Promotion({
    this.id,
    required this.name,
    required this.description,
    required this.isTrending,
    required this.image,
  });

  factory Promotion.fromJson(Map<String, dynamic> json) {
    const String baseUrl = 'http://192.168.8.101:5000/';
    return Promotion(
      id: json['_id'],
      name: json['name'],
      description: json['description'],
      isTrending: json['isTrending'],
      image: baseUrl + json['image'],
    );
  }
}
