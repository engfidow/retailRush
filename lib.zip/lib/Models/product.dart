import 'package:ecomerce/Models/Category_model.dart';

class Product {
  String? id;
  String? name;
  String? description;
  double? price;
  double? selprice;
  DateTime? selpriceDate;
  Category? category;
  bool? isTrending;
  int? unit;
  double rating;
  List<String>? images;
  bool isFavorite;

  Product({
    this.id,
    this.name,
    this.description,
    this.price,
    this.selprice,
    this.selpriceDate,
    this.category,
    this.isTrending = false,
    this.unit,
    this.images,
    this.rating = 0.0,
    this.isFavorite = false,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    const String baseUrl = 'http://192.168.8.101:5000/';
    return Product(
      id: json['_id'],
      name: json['name'],
      description: json['description'],
      price: (json['price'] as num).toDouble(),
      selprice: (json['selprice'] as num).toDouble(),
      selpriceDate: DateTime.parse(json['selpriceDate']),
      category:
          json['category'] != null ? Category.fromJson(json['category']) : null,
      isTrending: json['isTrending'],
      unit: json['unit'],
      rating: (json['rating'] as num).toDouble(),
      images: List<String>.from(json['images'].map((image) {
        return image.startsWith('http') ? image : baseUrl + image;
      })),
    );
  }

  Map<String, dynamic> toJson() => {
        '_id': id,
        'name': name,
        'description': description,
        'price': price,
        'selprice': selprice,
        'selpriceDate': selpriceDate?.toIso8601String(),
        'category': category?.toJson(),
        'isTrending': isTrending,
        'unit': unit,
        'rating': rating,
        'images': images,
        'isFavorite': isFavorite,
      };

  void clear() {
    id = null;
    name = null;
    description = null;
    price = null;
    selprice = null;
    selpriceDate = null;
    category = null;
    isTrending = false;
    unit = 0;
    rating = 0.0;
    images?.clear();
    isFavorite = false;
  }
}
