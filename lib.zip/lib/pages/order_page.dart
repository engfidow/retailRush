import 'package:flutter/material.dart';

class MyOrdersPage extends StatelessWidget {
  final List<OrderItem> orders = [
    OrderItem(
        name: 'Canon Camera',
        category: 'Electronics',
        price: 180,
        quantity: 2,
        imageUrl: 'assets/nike2.png'),
    OrderItem(
        name: 'Arm Chair',
        category: 'Furniture',
        price: 120,
        quantity: 2,
        imageUrl: 'assets/nike2.png'),
    OrderItem(
        name: 'Nike Pegasus 39',
        category: 'Shoes',
        price: 90,
        quantity: 2,
        imageUrl: 'assets/nike2.png'),
    OrderItem(
        name: 'Light Brown Coat',
        category: 'Clothes',
        price: 120,
        quantity: 2,
        imageUrl: 'assets/nike2.png'),
    OrderItem(
        name: 'Wood Chair',
        category: 'Furniture',
        price: 120,
        quantity: 2,
        imageUrl: 'assets/nike2.png'),
  ];

  MyOrdersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text('Orders'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Active'),
              Tab(text: 'Completed'),
              Tab(text: 'Cancelled'),
            ],
            labelColor: Colors.red,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.red,
          ),
        ),
        body: TabBarView(
          children: [
            OrdersList(orders: orders),
            Center(child: Text('Completed Orders')),
            Center(child: Text('Cancelled Orders')),
          ],
        ),
      ),
    );
  }
}

class OrdersList extends StatelessWidget {
  final List<OrderItem> orders;

  OrdersList({required this.orders});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: orders.length,
      itemBuilder: (context, index) {
        final order = orders[index];
        return ListTile(
          leading: Image.asset(order.imageUrl, width: 50, height: 50),
          title: Text(order.name),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${order.category} | Qty.: ${order.quantity} pcs'),
              Text('\$${order.price.toStringAsFixed(2)}'),
            ],
          ),
          trailing: ElevatedButton(
            onPressed: () {},
            child: Text(
              'Track Order',
              style: TextStyle(color: Colors.white),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              padding: EdgeInsets.symmetric(horizontal: 15),
              textStyle: TextStyle(fontSize: 12),
            ),
          ),
        );
      },
    );
  }
}

class OrderItem {
  final String name;
  final String category;
  final double price;
  final int quantity;
  final String imageUrl;

  OrderItem(
      {required this.name,
      required this.category,
      required this.price,
      required this.quantity,
      required this.imageUrl});
}
