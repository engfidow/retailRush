import 'package:ecomerce/providers/Cart.dart';
import 'package:ecomerce/providers/user_provider.dart';
import 'package:ecomerce/screens/Sigin_screen.dart';

import 'package:flutter/material.dart';
import 'package:iconly/iconly.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  void _onProfileTap() {
    // Handle profile tap
  }

  void _onManageAddressTap() {
    // Handle manage address tap
  }

  void _onPaymentMethodsTap() {
    // Handle payment methods tap
  }

  void _onMyOrdersTap() {
    // Handle my orders tap
  }

  void _onSettingsTap() {
    // Handle settings tap
  }

  void _onHelpCenterTap() {
    // Handle help center tap
  }

  void _onLogOutTap() {
    Provider.of<UserProvider>(context, listen: false).logout();
    Provider.of<CartProvider>(context, listen: false).clearCart();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (e) => const SigIn(),
      ),
    );
  }

  bool isValidUrl(String? url) {
    if (url == null || url.isEmpty) {
      return false;
    }
    return Uri.tryParse(url)?.hasAbsolutePath ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 60),
            Consumer<UserProvider>(
              builder: (context, userProvider, child) {
                var kEndpoint = "http://192.168.8.101:5000/";
                String imageUrl =
                    Uri.tryParse(kEndpoint + (userProvider.user?.image ?? ''))
                                ?.isAbsolute ==
                            true
                        ? kEndpoint + userProvider.user!.image!
                        : 'https://via.placeholder.com/150';
                return CircleAvatar(
                  radius: 50,
                  backgroundImage: CachedNetworkImageProvider(imageUrl),
                  child: Align(
                    alignment: Alignment.bottomRight,
                    child: CircleAvatar(
                      radius: 15,
                      backgroundColor: Colors.red,
                      child: Icon(
                        IconlyLight.edit,
                        size: 15,
                        color: Colors.white,
                      ),
                    ),
                  ),
                );
              },
            ),
            SizedBox(height: 10),
            Consumer<UserProvider>(
              builder: (context, userProvider, child) {
                return Text(
                  userProvider.user?.name ?? 'Guest',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                );
              },
            ),
            SizedBox(height: 20),
            _buildListTile(IconlyLight.user, 'Your profile', _onProfileTap),
            _buildListTile(
                IconlyLight.location, 'Manage Address', _onManageAddressTap),
            _buildListTile(Icons.payment_outlined, 'Payment Methods',
                _onPaymentMethodsTap),
            _buildListTile(
                Icons.list_alt_outlined, 'My Orders', _onMyOrdersTap),
            _buildListTile(IconlyLight.setting, 'Settings', _onSettingsTap),
            _buildListTile(Icons.help_outline, 'Help Center', _onHelpCenterTap),
            _buildListTile(IconlyLight.logout, 'LogOut', _onLogOutTap),
          ],
        ),
      ),
    );
  }

  Widget _buildListTile(IconData icon, String title, VoidCallback onTap) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 1,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: ListTile(
        leading: Icon(
          icon,
          color: Colors.red,
        ),
        title: Text(title),
        trailing: Icon(
          Icons.arrow_forward_ios,
          color: Colors.red,
        ),
        onTap: onTap,
      ),
    );
  }
}
