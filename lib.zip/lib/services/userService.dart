import 'dart:convert';
import 'package:ecomerce/utils/constants.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:ecomerce/Models/user_model.dart';
import 'dart:io';
import 'package:get_storage/get_storage.dart';

class UserService {
  final box = GetStorage();
  final String baseUrl = kEndpoint;

  Future<User?> createUser(User user, {File? image}) async {
    var uri = Uri.parse('$baseUrl/users/signup');
    var request = http.MultipartRequest('POST', uri)
      ..fields['name'] = user.name!
      ..fields['email'] = user.email!
      ..fields['password'] = user.password!;

    if (image != null) {
      request.files.add(await http.MultipartFile.fromPath('image', image.path));
    }

    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 201) {
      var userData = json.decode(response.body);
      saveUser(User.fromJson(userData)); // Save the user
      return User.fromJson(userData);
    } else {
      print('Failed to create user: ${response.statusCode}');
      print('Response body: ${response.body}');
      throw Exception('Failed to create user: ${response.body}');
    }
  }

  Future<User?> login(String email, String password) async {
    var response = await http.post(
      Uri.parse('$baseUrl/users/login'),
      headers: {"Content-Type": "application/json"},
      body: json.encode({'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      var userData = json.decode(response.body);
      saveUser(User.fromJson(userData)); // Save the user
      return User.fromJson(userData);
    } else {
      throw Exception('Failed to login');
    }
  }

  // Retrieve user from local storage
  User? getUser() {
    var userData = box.read(kUserInfo);

    if (userData != null) {
      return User.fromJson(json.decode(userData));
    }
    return null;
  }

  void saveUser(User user) {
    box.write(kUserInfo, json.encode(user.toJson()));
  }

  void clearUser() {
    box.remove(kUserInfo);
  }
}
